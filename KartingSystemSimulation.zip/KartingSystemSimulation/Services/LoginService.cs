﻿namespace KartingSystemSimulation.Services
{
    public class LoginService
    {
    }
}
