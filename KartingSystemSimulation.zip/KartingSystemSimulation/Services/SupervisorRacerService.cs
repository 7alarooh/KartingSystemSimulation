﻿namespace KartingSystemSimulation.Services
{
    public class SupervisorRacerService
    {
    }
}
