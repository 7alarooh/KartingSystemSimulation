﻿namespace KartingSystemSimulation.Enums
{
    public enum BookingCategory
    {
        Private,
        Group,
        Kids
    }
}
