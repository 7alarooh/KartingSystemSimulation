﻿namespace KartingSystemSimulation.Enums
{
    public enum KartType
    {
        Kids,
        Adults,
        Couples,
        Private
    }
}
