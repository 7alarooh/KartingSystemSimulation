﻿namespace KartingSystemSimulation.Enums
{
    public enum Role
    {
        Admin,
        Racer,
        Supervisor
    }
}
