﻿namespace KartingSystemSimulation.Enums
{
    public enum Address
    {
        Muttrah,
        Muscat,
        Bawshar,
        Seeb,
        AlAmirat,
        Qurayyat
    }
}
