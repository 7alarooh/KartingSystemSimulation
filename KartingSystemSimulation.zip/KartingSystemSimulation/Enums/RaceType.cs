﻿namespace KartingSystemSimulation.Enums
{
    public enum RaceType
    {
        Kids,
        Adults,
        Training,
        Unknown
    }
}
