﻿namespace KartingSystemSimulation.Enums
{
    public enum MembershipType
    {
        Normal,
        Gold,
        Dimond
    }
}
