﻿namespace KartingSystemSimulation.Enums
{
    public enum BookingType
    {
        Free,
        Paid
    }
}

