﻿namespace KartingSystemSimulation.Enums
{
    public enum Period
    {
        Weekly,
        Monthly,
        Yearly
    }
}
