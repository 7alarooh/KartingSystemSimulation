﻿namespace KartingSystemSimulation.DTOs.RaceBookingDTOs
{
    public class RaceBookingInputDTO
    {
    }
}
