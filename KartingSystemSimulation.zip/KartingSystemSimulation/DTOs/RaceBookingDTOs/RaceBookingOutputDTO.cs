﻿namespace KartingSystemSimulation.DTOs.RaceBookingDTOs
{
    public class RaceBookingOutputDTO
    {
    }
}
